<?php

return array (
  'MAILER_DSN' => NULL,
);
